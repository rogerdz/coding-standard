zip code:
zip -r coding-standard.zip . -x ./.git/**\*
